You do not need to run this program as admin.

make sure to extract everything into a folder or else it will not work.

Like the program says everything you download will go to the downloads
folder inside of this project.

Use the project responsibly, if you get banned from any of these clients,
that is on you not us.

Downloading any of these clients means you acknowledge the possible risk of ban.

Be careful and have fun. 